        function toggle() {
                for (var i=0; i<toggle.arguments.length; i++) {
                        var element = document.getElementById(toggle.arguments[i]);
                        element.style.display = (element.style.display == "" ? "none" : "");
                }
        }

        function toggleOn() {
                for (var i=0; i<toggleOn.arguments.length; i++) {
                        var element = document.getElementById(toggleOn.arguments[i]);
                        element.style.display = "";
                }
        }

        function toggleOff() {
                for (var i=0; i<toggleOff.arguments.length; i++) {
                        var element = document.getElementById(toggleOff.arguments[i]);
                        element.style.display = "none";
                }
        }

function processData(obj) {
	result = obj.outputString;
	result = result.replace("result=", "");
	
	// document.getElementById("test").innerHTML = "curl output: " + result;

	toggleOff("loading");

	toggleOn(result);
}

var gDoneButton;
var gInfoButton;
function setup() {
	gDoneButton = new AppleGlassButton(document.getElementById("doneButton"), "Done", hidePrefs);
	gInfoButton = new AppleInfoButton(document.getElementById("infoButton"), document.getElementById("front"), "white", "white", showPrefs);
	gInfoButton.setStyle("black","black");
	
	
	//> populate login info
	if(widget.preferenceForKey("username") != null)
		document.forms[1].username.value = widget.preferenceForKey("username");
	if(widget.preferenceForKey("password") != null)
		document.forms[1].password.value = widget.preferenceForKey("password");

	setTimeout("clearMessages()", 1000 * 60);
}

function clearMessages() {
	toggleOff("loading");
	toggleOff("404");
	toggleOff("504");
	toggleOff("401");
	toggleOff("505");

	setTimeout("clearMessages()", 1000 * 60);
}

function showPrefs()
{
    var front = document.getElementById("front");
    var back = document.getElementById("back");
 
    if (window.widget)
        widget.prepareForTransition("ToBack");
 
    front.style.display="none";
    back.style.display="block";
 
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);
}

function hidePrefs()
{
	//> save login info
	widget.setPreferenceForKey(document.forms[1].username.value, "username");
	widget.setPreferenceForKey(document.forms[1].password.value, "password");
	
    var front = document.getElementById("front");
    var back = document.getElementById("back");
 
    if (window.widget)
        widget.prepareForTransition("ToFront");
 
    back.style.display="none";
    front.style.display="block";
 
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);
}